export type SocialProofProps = {
    items: {
        text: string
        subText?: string
    }[]
    className?: string
}
