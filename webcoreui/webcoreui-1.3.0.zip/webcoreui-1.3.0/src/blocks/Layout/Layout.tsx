import React from 'react'
import { classNames } from 'webcoreui'
import { ConditionalWrapper, Footer, Menu } from 'webcoreui/react'

import SEO from '@blocks/SEO/SEO.tsx'

import type { ReactLayoutProps } from './layout'
import './layout.scss'

const Layout = ({
    seo,
    lang = 'en',
    menu,
    footer,
    className,
    containerClassName,
    bodyClassName,
    insideMenu,
    atf,
    leftSidebar,
    rightSidebar,
    aboveFooter,
    insideFooter,
    scripts,
    children,
    ...rest
}: ReactLayoutProps) => {
    const hasSidebar = leftSidebar || rightSidebar

    const containerClasses = classNames([
        containerClassName || 'container',
        hasSidebar && 'flex column md-row'
    ])

    return (
        <html lang={lang}>
            <head>
                <SEO {...seo} />
            </head>
            <body {...rest} className={bodyClassName}>
                {menu && (
                    <Menu {...menu}>
                        {insideMenu || <span />}
                    </Menu>
                )}
                {atf}
                <main className={containerClasses}>
                    {leftSidebar}
                    <ConditionalWrapper
                        condition={!!hasSidebar}
                        wrapper={children => <div className={className}>{children}</div>}
                    >
                        {children}
                    </ConditionalWrapper>
                    {rightSidebar}
                </main>
                {aboveFooter}
                {footer && (
                    <Footer {...footer}>
                        {insideFooter}
                    </Footer>
                )}
                {scripts}
            </body>
        </html>
    )
}

export default Layout
