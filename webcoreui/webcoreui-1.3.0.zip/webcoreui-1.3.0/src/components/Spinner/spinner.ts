export type SpinnerProps = {
    color?: string
    width?: number
    speed?: number
    size?: number
    dashArray?: number
}
